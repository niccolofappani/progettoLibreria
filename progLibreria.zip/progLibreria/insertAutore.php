<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "libreria";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) { //fallimento della connessione
      die("Connection failed: " . $conn->connect_error);
    }
    
    $Nome=$_POST['Nome'];
    $Cognome=$_POST['Cognome'];
    $DataNascita=$_POST['DataNascita'];
    $Nazionalità=$_POST['Nazionalità'];
   


    $query="select Autore.*, Libro.Titolo, Libro.ISBN10
            from Autore
            LEFT JOIN Libro ON Autore.IDAutore = Libro.CodAutore;"; 

    
    if($conn->query($query) === TRUE){
      $sql = "select Libro.IDLibro From Libro Where Libro.ISBN10 = '$ISBN'";
      $result = $conn->query($sql);
      while($row = $result->fetch_assoc()) {
        $ID = $row['IDLibro'];
        $sqlNuovo = "insert into TipoLibro(IDTipoLibro, Copie, Prezzo, Tipo) values($ID,$LibriNuovi, $Prezzo,'Nuovo')";
        $conn->query($sqlNuovo);
        $sqlUsato = "insert into TipoLibro(IDTipoLibro, Copie, Prezzo, Tipo) values($ID,$LibriUsati,$Prezzo/2,'Usato')";
        $conn->query($sqlUsato);
        
      }

      echo "Inserito con successo";
      echo "<form action='getQuery.php'><input type='submit' value='Catalogo' class='homebutton' id='btnHome' /></form>";
    }else{
      echo "Error:". $query . "<br>" . $conn->error;
    }
    $conn->close();
?>