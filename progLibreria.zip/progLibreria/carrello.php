<?php
    session_start();
    include('db_connect.php');
?>
<html>
    <head>
        <title>Carrello</title>
        <link rel="stylesheet" href="styles.css"  type="text/css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="index.php">Libreria Presta-Vendi</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="catalogo.php">Catalogo</a>
                    </li>
                </ul>
                <?php
                if(isset($_SESSION["logged"]) && $_SESSION["logged"]==true){
                    echo "
                    <label style='color: white'>Ciao, ". $_SESSION['user'] . "</label>&nbsp
                    <button class='btn btn-danger' onclick=document.location='logout.php'>Logout <i class='fa' style='font-size:20px;color:white'> &#xf08b;</i></button>&nbsp
                    <form class='form-inline my-2 my-lg-0'>
                        <div class=input-group rounded'>
                            <input type='search' class='form-control rounded' placeholder='Cerca' aria-label='Search' aria-describedby='search-addon' />
                            <button class='btn btn-primary'><i class='fa fa-search'></i></button>
                        </div>
                    </form>";
                        
                }
                else{
                    echo "<form class='form-inline my-2 my-lg-0'>
                        <button type='button' class='btn btn-primary' data-toggle='modal' data-target='#registerModal'>Registrazione</button>&nbsp&nbsp
                        <button type='button' class='btn btn-primary' data-toggle='modal' data-target='#loginModal'>Log-in</button>&nbsp&nbsp
                        <div class=input-group rounded'>
                            <input type='search' class='form-control rounded' placeholder='Cerca' aria-label='Search' aria-describedby='search-addon' />
                            <button class='btn btn-primary'><i class='fa fa-search'></i></button>
                        </div>
                        </form>";
                }
                ?>
            </div>  
        </nav>
                <?php
                if(isset($_SESSION["logged"]) && $_SESSION["logged"]==true){
                    $sql= "SELECT * FROM CarrelloLibri LEFT JOIN TipoLibro ON TipoLibro.IDTipoLibro=CarrelloLibri.IDLibro and TipoLibro.Tipo=CarrelloLibri.Tipo LEFT JOIN libro ON libro.IDLibro=TipoLibro.IDTipoLibro LEFT JOIN Autore ON Autore.IDautore=Libro.codAutore WHERE CarrelloLibri.IDutente='".$_SESSION['codFisc']."'";
                    $result=$conn->query($sql);
                    if($result -> num_rows > 0)
                    { 
                        echo "<div id='contenitore-carrello'>";
                        $prezzo = 0;
                        while($row = $result->fetch_assoc()){
                            $prezzo = $prezzo + ($row['Prezzo']*$row["Quantita"]);
                            echo "<div class='articolo-carrello'>
                            <br><form action='libroSingolo.php' method='get'><button type='submit' name='itemid' value='".$row['IDLibro']."' class='apriLibro'>".$row['Titolo']." di ".$row['Nome']." ".$row['Cognome']."</button></form> <br>
                            <form action='libroSingolo.php' method='get'><button type='submit' name='itemid' value='".$row['IDLibro']."' class='apriLibro'><img class='foto' src='".$row['Foto']."' alt='immagine'></button></form>
                            <button onclick='rimozione(".$row['IDLibro'].", `".$row['Tipo']."`)'>Rimuovi</button></div>";
                        }

                        echo "</div>";
                        echo "<div id='pagamento'>
                        <form action='charge.php' method='post'><input type='text' name='amount' value='20.00'>       
                        <button id='buy' onclick=''>Procedi al pagamento</button></form></div>";

                        
                        echo "<script src='rimuovi.js'></script>";
                    }else{
                        echo "
                        <h1>Il tuo carrello è vuoto</h1>
                        <h3>Inizia a fare acquisti cliccando <a href='catalogo.php'>qui</a></h3>
                        ";
                    }
                }
                else{
                    echo "<h1>Per poter accedere al carrello crea un account</h1>
                    <h2>Se hai già creato un account, esegui l'accesso</h2>";
                }
                ?>
    </body>
</html>

<?php
    include('modal.php');
?>