<?php
    session_start();
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "libreria";
    $conn = mysqli_connect($host, $user, $pass, $db) or die("Connessione non riuscita " . mysqli_connect_error() );
    $dataInizio = date('Y/m/d', strtotime($_POST['inizioPrestito']));
    $dataFine = date('Y/m/d', strtotime($_POST['inizioPrestito'] . ' + ' .  $_POST['durataPrestito'] . ' days'));
    $sql="INSERT INTO Prestito(IDUtente, IDLibro, DataInizio, DataFine)
    values('".$_SESSION['codFisc']."','".$_SESSION['row']['IDLibro']."','$dataInizio','$dataFine');";
    $result=$conn->query($sql);
    echo '
    <script>
        alert("Prestito confermato");
        location.href="catalogo.php";
    </script>'
    ?>