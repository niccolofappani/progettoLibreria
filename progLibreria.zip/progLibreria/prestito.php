<?php
    session_start();
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "libreria";
    $conn = mysqli_connect($host, $user, $pass, $db) or die("Connessione non riuscita " . mysqli_connect_error() );
    $dataInizio = date('Y/m/d', strtotime($_POST['inizioPrestito']));
    $dataFine = date('Y/m/d', strtotime($_POST['inizioPrestito'] . ' + ' .  $_POST['durataPrestito'] . ' days'));
    $sql="SELECT * FROM TipoLibro";
    $result=$conn->query($sql);
    if($result){
        if($_SESSION['row2']['Copie'] <= 0){
            echo "
            <script>
                alert('Copia non disponibile, impossibile effettuare il prestito');
                history.go(-1);
            </script>
            ";
        }
        else{
            $sql2="INSERT INTO Prestito(IDUtente, IDLibro, DataInizio, DataFine)
            values('".$_SESSION['codFisc']."','".$_SESSION['row']['IDLibro']."','$dataInizio','$dataFine');";
            $result=$conn->query($sql2);
            $sql3="UPDATE TipoLibro SET Copie = Copie - 1 WHERE IDTipoLibro = " . $_SESSION['row']['IDLibro'] . " AND Tipo = 'Usato'";
            $result=$conn->query($sql3);
            if($result){
                echo '
                <script>
                    alert("Prestito confermato");
                    location.href="catalogo.php";
                </script>';
            }
        }
    }
?>