<?php
    $host = "127.0.0.1";
    $user = "root";
    $pass = "";
    $db = "libreria";
    $conn = mysqli_connect($host, $user, $pass, $db) or die("Connessione non riuscita".mysqli_connect_error());
    $sql="DELETE FROM Prestito WHERE IDPrestito = '" . $_POST['IDPrestito'] ."'";
    $result=$conn->query($sql);
    if($result){
        echo "
        <script>
            alert('Prestito eliminato');
            history.go(-1);
        </script>";
    }
    else{
        echo 'Errore nell eliminazione del prestito';
    }
?>