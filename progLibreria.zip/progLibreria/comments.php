<?php
    include_once("db_connect.php");
    if(!empty($_POST["Commentatore"]) && !empty($_POST["Corpo"])){
        $insertComments = "INSERT INTO commento (idcorpo, corpo, commentatore) VALUES ('".$_POST["commentId"]."', '".$_POST["corpo"]."', '".$_POST["commentatore"]."')";
        mysqli_query($conn, $insertComments) or die("database error: ". mysqli_error($conn));	
        $message = '<label class="text-success">Commento inviato con successo.</label>';
        $status = array(
            'error'  => 0,
            'message' => $message
        );	
    } else {
        $message = '<label class="text-danger">Errore: Commento non inviato.</label>';
        $status = array(
            'error'  => 1,
            'message' => $message
        );	
    }

    echo json_encode($status);
?>