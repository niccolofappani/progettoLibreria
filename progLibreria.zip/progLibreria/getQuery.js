$('.catalogo').click(function(){
    $.ajax({
        type : "GET", 
        url : "getQuery.php",
        dataType: "json",
        success: window.location.reload()
        
    })
}